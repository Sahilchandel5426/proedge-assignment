const Index = () => {
    let pageProp = {
        "rollNumber": 0,
        "result": "No Data"
    };
    const getResult = async event => {
        event.preventDefault()
        var rollNumber = event.target.rollno.value
        const res = await fetch('http://localhost:5000/form', {
            body: JSON.stringify({
                rollNumber: rollNumber
            }),
            headers: {
                'Content-Type': 'application/json'
            },
            method: 'POST'
        })

        const result = await res.json()
        console.log(result)
        pageProp = { "rollNumber": rollNumber, "result": result.result }

    }



    return (
        <div>
            <h1>Home page</h1>

            <form onSubmit={getResult}>
                <label htmlFor="rollno">Find Result : </label>
                <input id="rollno" name="rollno" type="text" autoComplete="name" placeholder="Enter Roll Number" required />
                <button type="submit">Search</button>
            </form>

            <table>
                <thead>
                    <tr>
                        <th>Roll Number</th>
                        <th>Result</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>{pageProp.rollNumber}</td>
                        <td>{pageProp.result}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    )
}

export default Index