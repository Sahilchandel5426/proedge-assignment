const express = require('express');
const curl = require('curl');

const app = express();
app.set('trust proxy', true)


app.use(function (req, res, next) {

    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:3000');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);

    // Pass to next layer of middleware
    next();
});


app.use(express.json());



app.get('/', (req, res) => res.json({ error: "Not Authorized" }))

app.post('/form', (req, res) => {
    let rollNumber = req.body.rollNumber || null;
    curl.get("http://proedge.me/test.php?rollnumber=" + rollNumber, {}, function (err, response, body) {
        res.json({ result: body })
    });

})


var server = app.listen(5000, () => {
    console.log('Server Started on port ' + 5000);
});